# this Repo is a modified version of sveltejs template to be used in programming class. Yeah!

---

## svelte app

a svelte app consists of a main.js file this is where the fun begin (star wars ROTS)
It begins with APP.svelte which is our starting point.
From there we can create our own sub-components usually from the folder 'components'
