<script>

</script>

<main>
    <p></p>
<h1>Nyheds artikler til dig!</h1>
<h2>Her kan du browse og søge i flere tusinde nyheds artikler fra NewsAPI! Artiklerne kan være på mange sprog og kommer fra alle dele af verdenen!</h2>

</main>

<style>
    main{
        display: grid;
        place-items: center;
        grid-template-rows: 1fr 1fr 3fr;
        height: 100vh;
        width: 100%;
        top: 20vh;
        color: rgb(69, 154, 233);
    }
    main h2{
        width: 30vw;
    }
</style>